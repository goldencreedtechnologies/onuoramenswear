﻿ỌNUỌRA MENSWEAR — STAGE 2 BATCH
=================================

FILES UPDATED: 24

HOW TO APPLY
------------
1. Put onuora-stage2-batch.zip in C:\Users\HP\ONUORAMENSWEAR.
2. Stop npm run dev with Ctrl+C.
3. Extract the ZIP to .\stage2-installer.
4. Run:

   PowerShell -ExecutionPolicy Bypass `
     -File .\stage2-installer\onuora-stage2-batch\apply-onuora-stage2.ps1 `
     -ProjectRoot C:\Users\HP\ONUORAMENSWEAR

The installer:
- verifies the current source snapshot and required image assets;
- backs up overwritten files OUTSIDE the project at C:\Users\HP\ONUORA-BACKUPS;
- applies only the Stage 2 files;
- clears .next;
- runs npm run build.

IMPLEMENTED
-----------
- Uppercase primary desktop and mobile navigation labels.
- Mobile Client Services is one direct link with no nested menu.
- Product cards and galleries use seamless image surfaces without decorative frames.
- Smaller collection tags placed in the lower-right corner.
- Permanent collection cards share equal media heights.
- Ọzọ homepage artwork uses ndb3 (different model and burgundy outfit); Uzọ is unchanged.
- Heritage hero references use Heritage.jpg.
- About section uses From The Founder and founder.png.
- Collection filters are All, Nkwọ, Ọzọ and Uzọ with an active underline.
- All view is separated into Nkwọ, Ọzọ and Uzọ rows, four products maximum on desktop before horizontal scrolling.
- Product breadcrumbs use Heritage, Cowrie and Resort terminology.
- Journal imagery updated with founder.png, a different Craft model and new-product-b.png.
- Delivery priority/order and rules updated: international $50, Lagos complimentary, outside Lagos ₦15,000.
- Visible brand references audited to ỌNUỌRA.
- Announcement-bar behavior retained.

VALIDATION PERFORMED
--------------------
- Syntax transpilation passed for all 96 TypeScript/TSX files.
- All 21 /brand image references resolve against the supplied asset inventory/current assets.
- No visible legacy collection terminology remains in source.
- No heritage-draft.png source references remain.
- Static visible-button contrast audit found no dark-on-dark or light-on-light text controls.

IMAGE CHOICES
-------------
- Ọzọ card: /brand/products/button/ndb3/ndb3-studio-registered.webp
  Hover: /brand/products/button/ndb3/ndb3-angle.webp
- About/Home Heritage: /brand/Heritage.jpg
- Founder: /brand/founder.png
- Journal Craft: /brand/products/button/ndb3/ndb3-studio-registered.webp

NOTE
----
A full Next.js dependency build could not be run in the packaging environment because its package registry did not provide zod-validation-error@4.0.2. The installer runs the authoritative npm run build against your existing local installation.
