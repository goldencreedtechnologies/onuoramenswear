﻿ỌNUỌRA MENSWEAR — STAGE 3 BATCH
=================================

FILES UPDATED: 3

HOW TO APPLY
------------
1. Put onuora-stage3-batch.zip in C:\Users\HP\ONUORAMENSWEAR.
2. Stop npm run dev with Ctrl+C.
3. Extract the ZIP to .\stage3-installer.
4. Run:

   PowerShell -ExecutionPolicy Bypass `
     -File .\stage3-installer\onuora-stage3-batch\apply-onuora-stage3.ps1 `
     -ProjectRoot C:\Users\HP\ONUORAMENSWEAR

The installer:
- verifies the current Stage 2 source and required image assets;
- backs up overwritten files OUTSIDE the project at C:\Users\HP\ONUORA-BACKUPS;
- applies only the three Stage 3 files;
- clears .next;
- runs npm run build.

IMPLEMENTED
-----------
- Permanent Collections use three different approved models:
  Uzọ: ND3; Ọzọ: NDB2; Nkwọ: NDU.
- Each collection uses a matching same-product hover image.
- Ọzọ default: /brand/products/button/ndb2/ndb2-angle.webp
- Ọzọ hover: /brand/products/button/ndb2/ndb2-studio-registered.webp
- Ọzọ and Uzọ card imagery preserves the full model composition without head cropping.
- Founder portrait is removed from Journal and remains only in the Founder section.
- Heritage Journal: /brand/new-product-nb.png
- Craft Journal: /brand/new-product-btn/new-design-b-black.png
- Journal imagery uses contain framing to avoid clipping and distortion.
- Sitewide dark/light button contrast safeguard added without changing component structure.

ASSET PATH NOTE
---------------
The requested Craft filename is present in the project at the verified Linux-safe path:
public/brand/new-product-btn/new-design-b-black.png
The source uses that exact existing path to avoid a case-sensitive production 404.

VALIDATION PERFORMED
--------------------
- Syntax transpilation passed for all 96 TypeScript/TSX files.
- All Stage 3 image references resolve against the captured public asset inventory.
- founder.png is referenced only by app/about/page.tsx.
- Static visible-control audit found zero dark buttons/links without explicit light text.
- CSS braces and contrast safeguards were validated.

The installer runs the authoritative Next.js production build on your machine.
