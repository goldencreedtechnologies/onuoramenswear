﻿param(
  [string]$ProjectRoot = (Get-Location).Path,
  [switch]$Force
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$PackageRoot = $PSScriptRoot
$PayloadRoot = Join-Path $PackageRoot "payload"
$ManifestPath = Join-Path $PackageRoot "manifest.csv"

Write-Host ""
Write-Host "ỌNUỌRA Stage 3 Installer" -ForegroundColor Cyan
Write-Host "Project: $ProjectRoot"

if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "package.json"))) {
  throw "package.json was not found. Run this against the ONUORAMENSWEAR project root."
}

$requiredAssets = @(
  "public\brand\products\buttonless\nd3\nd3-studio-registered.webp",
  "public\brand\products\buttonless\nd3\nd3-angle.webp",
  "public\brand\products\button\ndb2\ndb2-angle.webp",
  "public\brand\products\button\ndb2\ndb2-studio-registered.webp",
  "public\brand\products\original\ndu\ndu-studio-idris.webp",
  "public\brand\products\original\ndu\ndu-angle.webp",
  "public\brand\new-product-nb.png",
  "public\brand\new-product-btn\new-design-b-black.png",
  "public\brand\new-product-b.png",
  "public\brand\founder.png"
)

$missingAssets = @()
foreach ($relative in $requiredAssets) {
  if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot $relative))) {
    $missingAssets += $relative
  }
}
if ($missingAssets.Count -gt 0) {
  throw ("Required Stage 3 image assets are missing:`n - " + ($missingAssets -join "`n - "))
}

$manifest = Import-Csv -LiteralPath $ManifestPath
$mismatches = @()
foreach ($item in $manifest) {
  $target = Join-Path $ProjectRoot $item.Path
  if (-not (Test-Path -LiteralPath $target)) {
    $mismatches += "$($item.Path) (missing)"
    continue
  }
  $hash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToUpperInvariant()
  if ($hash -ne $item.OriginalSHA256 -and $hash -ne $item.UpdatedSHA256) {
    $mismatches += "$($item.Path) (changed since Stage 2 was packaged)"
  }
}

if ($mismatches.Count -gt 0 -and -not $Force) {
  Write-Host ""
  Write-Host "Preflight stopped to avoid overwriting newer edits:" -ForegroundColor Yellow
  $mismatches | ForEach-Object { Write-Host " - $_" }
  Write-Host ""
  Write-Host "Stage 3 expects the completed Stage 2 source. Review those files before using -Force."
  exit 2
}

$ProjectParent = Split-Path -Parent $ProjectRoot
$BackupBase = Join-Path $ProjectParent "ONUORA-BACKUPS"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupRoot = Join-Path $BackupBase "stage3-$Timestamp"
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

Write-Host ""
Write-Host "Creating external backup: $BackupRoot"
foreach ($item in $manifest) {
  $source = Join-Path $ProjectRoot $item.Path
  if (Test-Path -LiteralPath $source) {
    $backup = Join-Path $BackupRoot $item.Path
    $backupParent = Split-Path -Parent $backup
    New-Item -ItemType Directory -Path $backupParent -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $backup -Force
  }
}

Write-Host "Applying Stage 3 files..."
foreach ($item in $manifest) {
  $source = Join-Path $PayloadRoot $item.Path
  $destination = Join-Path $ProjectRoot $item.Path
  if (-not (Test-Path -LiteralPath $source)) {
    throw "Installer payload is incomplete: $($item.Path)"
  }
  $destinationParent = Split-Path -Parent $destination
  New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
  Copy-Item -LiteralPath $source -Destination $destination -Force
  Write-Host "Updated $($item.Path)"
}

$nextCache = Join-Path $ProjectRoot ".next"
if (Test-Path -LiteralPath $nextCache) {
  Write-Host "Clearing .next cache..."
  Remove-Item -LiteralPath $nextCache -Recurse -Force
}

Write-Host ""
Write-Host "Running npm run build..." -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
  $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if ($null -ne $npm) {
    & npm.cmd run build
  } else {
    & npm run build
  }
  $buildExit = $LASTEXITCODE
} finally {
  Pop-Location
}

Write-Host ""
if ($buildExit -eq 0) {
  Write-Host "Stage 3 applied and the production build passed." -ForegroundColor Green
  Write-Host "Backup: $BackupRoot"
  Write-Host "Next: run npm run dev, review locally, then commit and push."
  exit 0
}

Write-Host "Stage 3 files were applied, but the production build failed." -ForegroundColor Red
Write-Host "Backup: $BackupRoot"
Write-Host "Fix the reported build error before committing or deploying."
exit $buildExit
