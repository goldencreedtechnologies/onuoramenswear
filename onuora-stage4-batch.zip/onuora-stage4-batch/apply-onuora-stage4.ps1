param(
  [Parameter(Mandatory = $false)]
  [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$ProjectRoot = (Resolve-Path $ProjectRoot).Path
$BatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$PayloadRoot = Join-Path $BatchRoot "payload"
$ManifestPath = Join-Path $BatchRoot "manifest.txt"

Write-Host "Preparing ỌNUỌRA Stage 4 update for $ProjectRoot..." -ForegroundColor Cyan

$requiredProjectFiles = @(
  "package.json",
  "tsconfig.json",
  "app\page.tsx",
  "components\product-options.tsx",
  "lib\backend\orders.ts"
)

foreach ($relativePath in $requiredProjectFiles) {
  $fullPath = Join-Path $ProjectRoot $relativePath
  if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
    throw "Required project file is missing: $relativePath"
  }
}

if (-not (Test-Path -LiteralPath $PayloadRoot -PathType Container)) {
  throw "Stage 4 payload folder was not found: $PayloadRoot"
}

if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
  throw "Stage 4 manifest was not found: $ManifestPath"
}

$manifest = Get-Content -LiteralPath $ManifestPath | Where-Object { $_.Trim().Length -gt 0 }
if (-not $manifest.Count) {
  throw "Stage 4 manifest is empty."
}

foreach ($relativePath in $manifest) {
  $payloadFile = Join-Path $PayloadRoot ($relativePath -replace "/", "\")
  if (-not (Test-Path -LiteralPath $payloadFile -PathType Leaf)) {
    throw "Payload file is missing: $relativePath"
  }
}

$projectParent = Split-Path -Parent $ProjectRoot
$backupBase = Join-Path $projectParent "ONUORA-BACKUPS"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $backupBase "stage4-$timestamp"
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

foreach ($relativePath in $manifest) {
  $windowsRelativePath = $relativePath -replace "/", "\"
  $sourcePath = Join-Path $PayloadRoot $windowsRelativePath
  $destinationPath = Join-Path $ProjectRoot $windowsRelativePath
  $backupPath = Join-Path $backupRoot $windowsRelativePath

  if (Test-Path -LiteralPath $destinationPath -PathType Leaf) {
    $backupParent = Split-Path -Parent $backupPath
    New-Item -ItemType Directory -Path $backupParent -Force | Out-Null
    Copy-Item -LiteralPath $destinationPath -Destination $backupPath -Force
  }

  $destinationParent = Split-Path -Parent $destinationPath
  New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
  Copy-Item -LiteralPath $sourcePath -Destination $destinationPath -Force
  Write-Host "Updated $relativePath"
}

$nextCache = Join-Path $ProjectRoot ".next"
if (Test-Path -LiteralPath $nextCache) {
  Remove-Item -LiteralPath $nextCache -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "" 
Write-Host "Stage 4 files applied." -ForegroundColor Green
Write-Host "Backup: $backupRoot" -ForegroundColor Yellow
Write-Host "" 
Write-Host "Running npm run build..." -ForegroundColor Cyan

Push-Location $ProjectRoot
try {
  & npm.cmd run build
  if ($LASTEXITCODE -ne 0) {
    throw "The Stage 4 files were applied, but npm run build failed with exit code $LASTEXITCODE. Your backup is at $backupRoot"
  }
}
finally {
  Pop-Location
}

Write-Host "" 
Write-Host "ỌNUỌRA Stage 4 build completed successfully." -ForegroundColor Green
Write-Host "Review the site locally before committing and pushing to main." -ForegroundColor Cyan
