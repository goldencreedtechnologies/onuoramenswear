ỌNUỌRA MENSWEAR — STAGE 4 FINAL BUILD

SCOPE
- Replaces the homepage hero with public/brand/main-hero.png.
- Includes a responsive crop at public/brand/main-hero-mobile.png derived from the same approved artwork.
- Uses NDB4 Studio Registered as the Ọzọ hover image and fills the collection card.
- Repositions the Founder portrait to preserve the full head and hairstyle.
- Retains Client Services and Policies because they serve different purposes.
  Client Services is guidance and concierge support; Delivery, Returns, Privacy and Terms remain detailed operational/legal pages.
- Repairs the existing /services#sizing and /services#care navigation targets.
- Adds Burnt Orange (#D9582E), Pale Beige (#DBAC76), and Royal Blue (#06058C) selectable swatches.
- Placeholder colours keep the current gallery visible, are stored in the bag, included in checkout, shown in Stripe line items, and recorded in order-event metadata.
- Ensures product/editorial imagery fills its approved containers without introducing frames.

APPLY
1. Stop npm run dev.
2. Extract the ZIP into a temporary folder.
3. Run apply-onuora-stage4.ps1 with -ProjectRoot pointing to the project.
4. The script backs up modified files outside the project, clears .next, and runs npm run build.

LOCAL QA
- Homepage desktop and mobile hero.
- Ọzọ default/hover transition.
- About Founder portrait.
- One product page: select each new colour, select a size, Add To Bag.
- Shopping bag, mini bag, checkout summary and Stripe test checkout.
- /services#sizing and /services#care.
- Navigation and all policy routes.

DEPLOY AFTER QA
  git status
  git diff --stat
  git add app components data lib public/brand/main-hero.png public/brand/main-hero-mobile.png public/brand/products/button/ndb4/ndb4-studio-registered.webp
  git commit -m "Complete Stage 4 final refinements"
  git switch main
  git pull --ff-only origin main
  git push origin main

If your Stage 4 commit was created on another branch, merge that branch into main before pushing instead of switching after the commit.
