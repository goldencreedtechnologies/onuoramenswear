param(
  [Parameter(Mandatory = $true)]
  [string]$BackupPath,
  [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$BackupPath = (Resolve-Path $BackupPath).Path
$ProjectRoot = (Resolve-Path $ProjectRoot).Path

Get-ChildItem -Path $BackupPath -File -Recurse | ForEach-Object {
  $RelativePath = $_.FullName.Substring($BackupPath.Length).TrimStart('\', '/')
  $Destination = Join-Path $ProjectRoot $RelativePath
  New-Item -ItemType Directory -Path (Split-Path $Destination) -Force | Out-Null
  Copy-Item $_.FullName $Destination -Force
  Write-Host "Restored $RelativePath" -ForegroundColor Yellow
}

# Remove the two new Stage 1 files if they did not exist in the backup.
foreach ($NewFile in @("components\currency-provider.tsx", "data\site-config.ts")) {
  if (-not (Test-Path (Join-Path $BackupPath $NewFile))) {
    Remove-Item (Join-Path $ProjectRoot $NewFile) -Force -ErrorAction SilentlyContinue
  }
}

Remove-Item (Join-Path $ProjectRoot ".next") -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Rollback complete. Run npm run build." -ForegroundColor Green
