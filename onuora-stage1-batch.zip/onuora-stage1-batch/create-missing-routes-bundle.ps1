param([string]$ProjectRoot = (Get-Location).Path)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path $ProjectRoot).Path
Push-Location $ProjectRoot
try {
  $Targets = @(
    "app\api\checkout",
    "app\api\stripe",
    "app\api\delivery",
    "app\products",
    "app\collection",
    "app\collections",
    "app\cart",
    "app\checkout",
    "app\about",
    "app\services",
    "app\shipping",
    "app\returns",
    "app\journal",
    "supabase\migrations",
    "supabase\schema.sql"
  ) | Where-Object { Test-Path $_ }

  tar.exe -a -c -f "onuora-stage1-missing-routes.zip" @Targets
  Write-Host "Created $ProjectRoot\onuora-stage1-missing-routes.zip" -ForegroundColor Green
} finally {
  Pop-Location
}
