ỌNUỌRA MENSWEAR — FOUNDER STAGE 1 BATCH

WHAT THIS BATCH DOES
- Centralises brand, collection, product-price, currency, delivery-copy and promotion configuration.
- Uses Heritage — Nkwọ, Cowrie — Ọzọ and Resort — Uzọ consistently in supplied shared source.
- Sets every standard outfit to the fixed prices: NGN 120,000 / GBP 90 / USD 120 / EUR 100.
- Adds a visible persistent currency selector with first-visit locale/time-zone suggestion.
- Updates product cards, collection cards, cart, mini-cart and checkout display.
- Adds “Complete Two-Piece Outfit” and “Top And Trousers Included” language.
- Updates announcement, navigation, footer, metadata, Nigerian-origin and worldwide-delivery copy.
- Applies Title Case to major headings and naming in the supplied source.
- Preserves routes, images, CSS rules, layouts, spacing, animations and payment provider.

HOW TO APPLY
1. Put this extracted folder anywhere convenient.
2. Open PowerShell in C:\Users\HP\ONUORAMENSWEAR
3. Run:

   PowerShell -ExecutionPolicy Bypass -File "FULL_PATH_TO_THIS_FOLDER\apply-onuora-stage1.ps1"

The script backs up every overwritten file, clears .next and runs npm run build.

IMPORTANT LIMITATION
The source ZIP supplied to ChatGPT did not include the following project files:
- app/api/checkout/route.ts
- the Stripe Checkout session-creation route
- app/products/[slug]/page.tsx
- app/collection/page.tsx and app/collections/page.tsx
- the remaining route-level page files
- Supabase order/price migrations

Therefore this batch safely sends, stores and displays the selected currency in the supplied shared source, but it does not guess or overwrite the unseen Stripe session code. The actual Stripe charge currency and transactional promotion enforcement must be verified in those missing route files before Stage 1 can be called fully complete.

VALIDATION COMPLETED HERE
- All supplied TypeScript and TSX files passed a syntax/transpile check.
- No obsolete public collection-name strings remain in the patched supplied source.
- No public-facing generic luxury/premium strings remain in the patched supplied source.
- A full Next.js build could not run in ChatGPT because the internal package mirror returned a missing-package 404. The installer runs the real build on your machine.
