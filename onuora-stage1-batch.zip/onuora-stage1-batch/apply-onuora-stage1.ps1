param(
  [string]$ProjectRoot = (Get-Location).Path,
  [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path $ProjectRoot).Path
$PayloadRoot = Join-Path $PSScriptRoot "payload"

if (-not (Test-Path (Join-Path $ProjectRoot "package.json"))) {
  throw "Run this script from the ONUORAMENSWEAR project root, or pass -ProjectRoot C:\path\to\ONUORAMENSWEAR."
}

if (-not (Test-Path $PayloadRoot)) {
  throw "The payload folder is missing. Keep apply-onuora-stage1.ps1 beside the payload folder."
}

# Stop a local dev server so stale Turbopack output cannot cause hydration mismatches.
try {
  Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
} catch {
  Write-Warning "Could not automatically stop port 3000. Stop npm run dev manually if it is still running."
}

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupRoot = Join-Path $ProjectRoot "_stage1_backup_$Timestamp"
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

$PayloadFiles = Get-ChildItem -Path $PayloadRoot -File -Recurse
foreach ($SourceFile in $PayloadFiles) {
  $RelativePath = $SourceFile.FullName.Substring($PayloadRoot.Length).TrimStart('\', '/')
  $Destination = Join-Path $ProjectRoot $RelativePath
  $BackupDestination = Join-Path $BackupRoot $RelativePath

  if (Test-Path $Destination) {
    New-Item -ItemType Directory -Path (Split-Path $BackupDestination) -Force | Out-Null
    Copy-Item $Destination $BackupDestination -Force
  }

  New-Item -ItemType Directory -Path (Split-Path $Destination) -Force | Out-Null
  Copy-Item $SourceFile.FullName $Destination -Force
  Write-Host "Updated $RelativePath" -ForegroundColor Cyan
}

Remove-Item (Join-Path $ProjectRoot ".next") -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Stage 1 shared-source update applied." -ForegroundColor Green
Write-Host "Backup: $BackupRoot" -ForegroundColor Yellow

if (-not $SkipBuild) {
  Push-Location $ProjectRoot
  try {
    Write-Host ""
    Write-Host "Running npm run build..." -ForegroundColor Cyan
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) {
      Write-Warning "The files were applied, but the build failed. Review the error above. Your backup is at $BackupRoot"
      exit $LASTEXITCODE
    }
  } finally {
    Pop-Location
  }

  Write-Host ""
  Write-Host "Build passed." -ForegroundColor Green
}

Write-Host ""
Write-Host "Review with:" -ForegroundColor White
Write-Host "  git status"
Write-Host "  git diff"
Write-Host ""
Write-Host "Then deploy with:" -ForegroundColor White
Write-Host "  git add ."
Write-Host '  git commit -m "Apply founder Stage 1 brand and commerce structure"'
Write-Host "  git push"
